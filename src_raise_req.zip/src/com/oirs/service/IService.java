package com.oirs.service;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;

public interface IService 
{
	int storeData(Requisition r) ;
	
	public boolean validateId(String Id);
	public boolean validateVacancyDomain(String vacancy);
	public boolean validateSkill(String level);
	public boolean checkLogin(User user);
}