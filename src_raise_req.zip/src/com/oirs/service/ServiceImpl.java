package com.oirs.service;

import java.util.Scanner;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;
import com.oirs.dao.DaoImpl;
import com.oirs.dao.IDao;

public class ServiceImpl implements IService 
{
	Scanner scan =  new Scanner(System.in);
	@Override
	public boolean validateId(String Id) 
	{
		System.out.println("Enter ID:");
		String id= scan.next();
		if(id.matches("[A-Z]{2}[0-9]{2}"))
		return true;
		else
		return false;
	}
	@Override
	public boolean validateVacancyDomain(String vacancy) 
	{
		System.out.println("Enter vacancy name:");
		String vac= scan.next();
		/*System.out.println("Enter domain:");
		String dom = scan.next();*/
		if(vac.matches("[A-Z]{1}[a-z]{1,}"))
			return true;
		else
		return false;
	}
	@Override
	public boolean validateSkill(String level) {
		System.out.println("Enter Skill Level");
		String lev=scan.next();
		if(lev.matches("[l]{1}[e]{1}[v]{1}[e]{1}[l]{1}[0-9]{1}"))
			return true;
		else
		return false;
	}
	
	@Override
	public boolean checkLogin(User user) {
		IDao dao=new DaoImpl();
		return dao.checkLogin(user);
	}
	

	@Override
	public int storeData(Requisition r){
		IDao idao=new DaoImpl();
		return idao.storeData(r);
	}
	
}
