package com.oirs.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnector {
	
	public static Connection con;
	private static String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	private static String user="trg1101";
	private static String password="training1101";
	
	public static Connection getConnected() 
	{

		try 
		{
			
			con=DriverManager.getConnection(url, user, password);
			
		} catch (SQLException e)
		{
			e.printStackTrace();
			
		}
		return con;
	}

}
