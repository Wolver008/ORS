package com.oirs.bean;

public class Requisition 
{
	private String requisitionId;
	private String dateCreated;
	private String  dateClosed;
	private String currentStatus;
	private String vacancyName;
	private String skill;
	private String domain;
	private int numberRequired;
	private String projectId;
	private String RMID;

	public Requisition()
	{
		
	}

	public Requisition(String requisitionId, String dateCreated,
			String dateClosed, String currentStatus, String vacancyName,
			String skill, String domain, int numberRequired, String projectId,
			String rMID) 
	{
		this.requisitionId = requisitionId;
		this.dateCreated = dateCreated;
		this.dateClosed = dateClosed;
		this.currentStatus = currentStatus;
		this.vacancyName = vacancyName;
		this.skill = skill;
		this.domain = domain;
		this.numberRequired = numberRequired;
		this.projectId = projectId;
		RMID = rMID;
	}

	public String getRequisitionId() {
		return requisitionId;
	}

	public void setRequisitionId(String string) {
		this.requisitionId = string;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDateClosed() {
		return dateClosed;
	}

	public void setDateClosed(String dateClosed) {
		this.dateClosed = dateClosed;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getVacancyName() {
		return vacancyName;
	}

	public void setVacancyName(String vacancyName) {
		this.vacancyName = vacancyName;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public int getNumberRequired() {
		return numberRequired;
	}

	public void setNumberRequired(int numberRequired) {
		this.numberRequired = numberRequired;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRMID() {
		return RMID;
	}

	public void setRMID(String rMID) {
		RMID = rMID;
	}
	

	
}
